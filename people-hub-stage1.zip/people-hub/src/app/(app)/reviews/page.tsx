// My Reviews — the employee landing page.
// Stage 1 shows the person's identity and reporting context. The review
// instruments (Quarterly, Values, Year-End) are built in later stages, so this
// screen currently states that clearly rather than faking review cards.

import { getCurrentUser } from "@/core/auth";
import { requireSignedIn } from "@/core/access";
import { prisma } from "@/shared/lib/prisma";

export default async function MyReviewsPage() {
  const user = requireSignedIn(await getCurrentUser());
  const me = await prisma.employee.findUnique({
    where: { id: user.employeeId },
    include: { manager: true },
  });

  return (
    <div>
      <h1>My Reviews</h1>
      <div className="card">
        <strong>{me?.displayName}</strong>
        <div className="muted">
          {me?.role ?? "—"} · {me?.department ?? "—"}
        </div>
        <div className="muted">
          Manager: {me?.manager?.displayName ?? "—"}
        </div>
        <div className="muted">
          Rating guide: {me?.ratingGuideCategory ?? "not assigned"}
        </div>
      </div>
      <div className="empty">
        Your quarterly reviews, annual values review, and year-end summary will
        appear here. The review workflow is delivered in a later stage.
      </div>
    </div>
  );
}
